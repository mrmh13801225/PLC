package main.symbolTable.exceptions;

public class IncosistanceReturn extends Exception{
}
