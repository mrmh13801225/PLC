package main.ast.nodes.expression;

public enum RangeType {
    LIST, DOUBLE_DOT, IDENTIFIER
}
