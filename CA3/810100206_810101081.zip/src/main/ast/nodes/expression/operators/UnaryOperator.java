package main.ast.nodes.expression.operators;

public enum UnaryOperator {
    NOT, MINUS, INC, DEC
}
